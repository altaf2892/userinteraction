package com.example.userinteraction.model

class DataModel {

    var fullname: String = ""
    var email: String = ""
    var phone: String = ""
    var birthday: Long = 0
    var _id: String = ""
    var gender: String = ""
    var website: String = ""
    val image: String = ""
    var addressModel: AddressModel? = null
    var usrr_email: String = ""


    class AddressModel {



        var street: String = ""
        var streetName: String = ""
        var buildingNumber: String = ""
        var city: String = ""
        var zipcode: String = ""
        var country: String = ""
        var county_code: String = ""
        var latitude: String = ""
        var longitude: String = ""

    }
}