package com.example.userinteraction.utility

import android.content.Context
import android.graphics.Color
import androidx.fragment.app.FragmentActivity
import com.kaopiz.kprogresshud.KProgressHUD

object ProgressUtils {


    fun initProgressBar(context: Context, msg: String): KProgressHUD? {
        return KProgressHUD.create(context).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
            .setCancellable(false)
            .setLabel(msg, Color.WHITE)
            .setAnimationSpeed(1)
            .setDimAmount(0.5f)
    }

   /* fun initProgressBar(context: Context): KProgressHUD? {
        return KProgressHUD.create(context).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
            .setCancellable(false)
            .setAnimationSpeed(1)
            .setDimAmount(0.5f)
    }*/
    fun initProgressBar(context: FragmentActivity?): KProgressHUD? {
        return KProgressHUD.create(context).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
            .setCancellable(false)
            .setAnimationSpeed(1)
            .setDimAmount(0.5f)
    }


    fun showDialog(dialog: KProgressHUD, isLoaderRequired: Boolean) {
        if (!dialog.isShowing)
            if (isLoaderRequired)
                dialog.show()
    }

    fun dismissDialog(dialog: KProgressHUD) {
        if (dialog.isShowing)
            dialog.dismiss()

    }

    fun getInstance(): ProgressUtils {
        return this

    }


}