package com.example.userinteraction.ui.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.userinteraction.R
import com.example.userinteraction.databinding.FragmentProfileBinding
import com.google.firebase.auth.ktx.userProfileChangeRequest

class ProfileFragment : BaseFragment(R.layout.fragment_profile) {

    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        loadata()
    }

    private fun loadata() {
        val user = auth.currentUser
        binding.editFName.setText(user!!.displayName)
        binding.editEmail.setText(user.email)
        binding.btbUpdate.setOnClickListener {
            if (!binding.editFName.text.toString().isEmpty()) {

                val profileUpdates = userProfileChangeRequest {
                    displayName = binding.editFName.text.toString()
                }
                showLoader()
                user.updateProfile(profileUpdates)
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            hideLoader()

                        }
                    }.addOnFailureListener {
                        hideLoader()
                    }
            }

        }

    }


}
