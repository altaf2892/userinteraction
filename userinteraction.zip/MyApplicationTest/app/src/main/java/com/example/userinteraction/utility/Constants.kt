package com.example.userinteraction.utility

object Constants {

    const val USER_MODEL = "userModel"
    const val ISLOGIN = "ISLOGIN"

}