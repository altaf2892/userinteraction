package com.example.userinteraction.ui.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.userinteraction.R
import com.example.userinteraction.adapter.FriendsAdapter
import com.example.userinteraction.databinding.FragmentMainBinding
import com.example.userinteraction.model.DataModel
import com.example.userinteraction.model.UserModel
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.growhub.utility.SharedPrefsHelper


class FriendsFragment : BaseFragment(R.layout.fragment_main) {
    private var _binding: FragmentMainBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        _binding = FragmentMainBinding.inflate(inflater, container, false)

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        loadata()
    }

    private fun loadata() {
        showLoader()
        val userEmail: UserModel? = SharedPrefsHelper.getUserDetails()
        gettaskRef().child(userEmail?.id.toString())
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    hideLoader()

                     val list = ArrayList<DataModel>()


                    for (s in snapshot.children) {

                        val model: DataModel? = s.getValue(
                            DataModel::class.java)
                        if (model != null) {
                            list.add(model)
                        }


                    }

                    setData(list)

                }

                override fun onCancelled(error: DatabaseError) {
                    hideLoader()
                }
            })
    }

    private fun setData(list: java.util.ArrayList<DataModel>) {

        binding.rvFriends.adapter=FriendsAdapter(activity,list)

    }
}