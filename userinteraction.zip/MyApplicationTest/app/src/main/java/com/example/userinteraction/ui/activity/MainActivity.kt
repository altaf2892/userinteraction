package com.example.userinteraction.ui.activity

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.Window
import android.view.WindowManager
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.core.view.GravityCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentStatePagerAdapter
import androidx.fragment.app.FragmentStatePagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT
import androidx.viewpager.widget.ViewPager
import com.example.userinteraction.R
import com.example.userinteraction.databinding.ActivityMainBinding
import com.example.userinteraction.ui.fragment.FriendsFragment
import com.example.userinteraction.ui.fragment.ProfileFragment
import com.example.userinteraction.utility.Constants
import com.example.userinteraction.utility.Utils
import com.google.android.material.tabs.TabLayout
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import com.growhub.utility.SharedPrefsHelper
import java.util.*

class MainActivity : BaseActivity() {

    lateinit var binding: ActivityMainBinding
    lateinit var adapter: TabAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );
        setContentView(binding.root)

        if (!SharedPrefsHelper.getBooleanFromPref(Constants.ISLOGIN))

            startActivity(Intent(this, LoginActivity::class.java))
        else
            init()

    }


    private fun init() {
        setupDrawer()
        adapter = TabAdapter(
            supportFragmentManager, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT
        )
        adapter.addFragment(FriendsFragment(), getString(R.string.text_friends))
        adapter.addFragment(ProfileFragment(), getString(R.string.text_my_profile))

        binding.viewPager.setAdapter(adapter)

        binding.fabAdd.setOnClickListener {

            startActivity(Intent(this, AddFriendActivity::class.java))
        }
        binding.viewPager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int
            ) {

            }

            override fun onPageSelected(position: Int) {
                setVIsibility(position)

            }

            override fun onPageScrollStateChanged(state: Int) {

            }

        })

        binding.tabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {

            override fun onTabSelected(tab: TabLayout.Tab?) {
                // Handle tab select

                setVIsibility(tab!!.position)


            }

            override fun onTabReselected(tab: TabLayout.Tab?) {
                // Handle tab reselect

            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {
                // Handle tab unselect
            }
        })
    }

    private fun setupDrawer() {

        val toggle = ActionBarDrawerToggle(
            this,
            binding.drawerLayout,
            binding.toolbar,
            R.string.navigation_drawer_open,
            R.string.navigation_drawer_close
        )
        binding.drawerLayout.addDrawerListener(toggle)
        toggle.syncState()


        binding.navView.setNavigationItemSelectedListener { item ->
            closeDrawer()
            when (item.itemId) {
                R.id.nav_exit -> {
                    Firebase.auth.signOut()
                    Utils.logout(getActivity())



                    true
                }

                else -> {
                    false
                }

            }


        }
    }

    private fun getActivity(): MainActivity {
        return this
    }

    private fun closeDrawer() {
        binding.drawerLayout.closeDrawer(GravityCompat.START)
    }

    private fun setVIsibility(i: Int) {
        val fragment: Fragment = adapter.getItem(i)
        if (fragment.isVisible())

            when (i) {

                0 -> {
                    binding.fabAdd.visibility = View.VISIBLE
                }
                1 -> {
                    binding.fabAdd.visibility = View.GONE
                }
            }
    }


    class TabAdapter internal constructor(fm: FragmentManager, behavior: Int) :
        FragmentStatePagerAdapter(fm, behavior) {
        private val mFragmentList: MutableList<Fragment> = ArrayList()
        private val mFragmentTitleList: MutableList<String> = ArrayList()
        override fun getItem(position: Int): Fragment {
            return mFragmentList[position]
        }

        fun addFragment(fragment: Fragment, title: String) {
            mFragmentList.add(fragment)
            mFragmentTitleList.add(title)
        }


        override fun getPageTitle(position: Int): CharSequence? {
            return mFragmentTitleList[position]
        }

        override fun getCount(): Int {
            return mFragmentList.size
        }
    }

}