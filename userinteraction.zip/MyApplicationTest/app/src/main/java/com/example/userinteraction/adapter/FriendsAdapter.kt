package com.example.userinteraction.adapter

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.annotation.NonNull
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import com.example.userinteraction.R
import com.example.userinteraction.model.DataModel
import com.example.userinteraction.ui.activity.FriendMapActivity
import com.example.userinteraction.utility.Constants
import com.google.gson.Gson

internal class FriendsAdapter(private val context: FragmentActivity?, private var friendsList: List<DataModel>) :
    RecyclerView.Adapter<FriendsAdapter.MyViewHolder>() {
    internal inner class MyViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var title: TextView = view.findViewById(R.id.tv_name)

    }

    @NonNull
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.friends_item, parent, false)
        return MyViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val friendModel = friendsList[position]
        holder.title.text = friendModel.fullname

        holder.itemView.setOnClickListener {
            context?.startActivity(Intent(context, FriendMapActivity::class.java).apply {
                putExtra(Constants.USER_MODEL, Gson().toJson(friendModel))
            })

        }

    }

    override fun getItemCount(): Int {
        return friendsList.size
    }
}