package com.example.userinteraction.utility

import androidx.multidex.MultiDexApplication

class MyApplication  : MultiDexApplication() {

    companion object {
        lateinit var instance: MyApplication
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }
}