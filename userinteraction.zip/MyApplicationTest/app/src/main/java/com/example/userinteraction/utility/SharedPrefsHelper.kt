package com.growhub.utility

import android.content.Context
import android.content.SharedPreferences
import com.example.userinteraction.model.UserModel
import com.example.userinteraction.utility.Constants
import com.example.userinteraction.utility.MyApplication
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken


object SharedPrefsHelper {

    private const val SHARED_PREFS_NAME = "TODO"

    private var sharedPreferences: SharedPreferences = MyApplication.instance.getSharedPreferences(
        SHARED_PREFS_NAME, Context.MODE_PRIVATE
    )

    fun getStringFromPref(key: String): String {
        return sharedPreferences.getString(key, "").toString()
    }

    fun setStringToPref(key: String, value: String?) {
        getEditor().putString(key, value).apply()
    }

    fun getIntegerFromPref(key: String?): Int {
        return sharedPreferences.getInt(key, 0)
    }

    fun setIntegerToPref(key: String, value: Int) {
        getEditor().putInt(key, value).apply()
    }

    fun getBooleanFromPref(key: String): Boolean {
        return sharedPreferences.getBoolean(key, false)
    }

    fun setBooleanToPref(key: String, value: Boolean) {
        getEditor().putBoolean(key, value).apply()
    }


    fun delete(key: String) {
        if (sharedPreferences.contains(key)) {
            getEditor().remove(key).commit()
        }
    }

    //Clear all data
    fun clear() {
        getEditor().clear().apply()
    }

    private fun getEditor(): SharedPreferences.Editor {
        return sharedPreferences.edit()
    }

    fun getUserDetails(): UserModel? {
        return toUserDetails(getStringFromPref(Constants.USER_MODEL))
    }

    fun setUserDetails(userMap: UserModel?) {
        if (userMap != null) setStringToPref(
            Constants.USER_MODEL,
            toJsonString(userMap)
        ) else setStringToPref(Constants.USER_MODEL, null)
    }

    private fun toJsonString(params: UserModel): String {
        val mapType = object : TypeToken<UserModel?>() {}.type
        val gson = Gson()
        return gson.toJson(params, mapType)
    }

    private fun toUserDetails(params: String): UserModel? {
        val mapType = object : TypeToken<UserModel?>() {}.type
        val gson = Gson()
        return gson.fromJson(params, mapType)
    }

}