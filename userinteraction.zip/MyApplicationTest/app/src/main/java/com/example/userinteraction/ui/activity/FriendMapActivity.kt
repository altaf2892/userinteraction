package com.example.userinteraction.ui.activity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.userinteraction.R
import com.example.userinteraction.databinding.MainMapBinding
import com.example.userinteraction.model.DataModel
import com.example.userinteraction.utility.Constants
import com.example.userinteraction.utility.Utils
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.gson.Gson

class FriendMapActivity : AppCompatActivity(), OnMapReadyCallback {
    lateinit var binding: MainMapBinding
    private lateinit var mMap: GoogleMap
    private var data = DataModel()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = MainMapBinding.inflate(layoutInflater)
        setContentView(binding.root)
        init()
    }

    private fun init() {
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        data = Gson().fromJson(intent.getStringExtra(Constants.USER_MODEL), DataModel::class.java)

        setData()


        val lat: Double = data.addressModel!!.latitude.toDouble()
        val lon: Double = data.addressModel!!.longitude.toDouble()
        // Add a marker in Sydney and move the camera
        val loc = LatLng(lat, lon)
        mMap.addMarker(
            MarkerOptions()
                .position(loc)
                .title(data.fullname)
        )
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(loc, 15F))
    }

    private fun setData() {
        binding.tvFname.text = getString(R.string.text_full_name).plus(" :").plus(data.fullname)
        binding.tvEmail.text = getString(R.string.text_email).plus(":  ").plus(data.email)
        binding.tvPhone.text = getString(R.string.text_phone).plus(" : ").plus(data.phone)
        binding.tvBNo.text = getString(R.string.text_birthday).plus(" : ")
            .plus(Utils.convertLongToTime(data.birthday))
        binding.tvGender.text = getString(R.string.text_gender).plus(" : ").plus(data.gender)
        binding.tvStreet.text =
            getString(R.string.text_street).plus(" :").plus(data.addressModel!!.street)
        binding.tvStreetName.text =
            getString(R.string.text_streetName).plus(" :").plus(data.addressModel!!.streetName)
        binding.tvBNo.text = getString(R.string.text_buildingNumber).plus(" :")
            .plus(data.addressModel!!.buildingNumber)
        binding.tvCity.text =
            getString(R.string.text_city).plus(" :").plus(data.addressModel!!.city)
        binding.tvZipcode.text =
            getString(R.string.text_zipcode).plus(" :").plus(data.addressModel!!.zipcode)
        binding.tvCon.text =
            getString(R.string.text_county_code).plus(" :").plus(data.addressModel!!.country)
        binding.tvConCode.text =
            getString(R.string.text_county_code).plus(" :").plus(data.addressModel!!.county_code)
        binding.tvWeb.text = getString(R.string.text_website).plus(" :").plus(data.website)

    }
}