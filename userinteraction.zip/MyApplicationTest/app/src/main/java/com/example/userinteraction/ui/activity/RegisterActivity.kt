package com.example.userinteraction.ui.activity

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import com.example.userinteraction.R
import com.example.userinteraction.databinding.ActivityRegisterBinding
import com.example.userinteraction.model.UserModel
import com.example.userinteraction.utility.Constants
import com.example.userinteraction.utility.Utils
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseUser
import com.growhub.utility.SharedPrefsHelper
import java.util.*


class RegisterActivity : BaseActivity() {


    lateinit var binding: ActivityRegisterBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)
        init()
    }

    private fun init() {


        binding.btbRegister.setOnClickListener {


            if (isValid()) {

                val fname: String = binding.editFName.text.toString().trim()
                val email: String = binding.editEmail.text.toString().trim()
                val password: String = binding.editPassword.text.toString().trim()
                doRequestForRegister(UserModel(fname, email, password,UUID.randomUUID().toString()))

            }


        }

        binding.tvLogin.setOnClickListener {
            startActivity(Intent(applicationContext, LoginActivity::class.java))
        }

    }


    private fun isValid(): Boolean {
        val fname: String = binding.editFName.text.toString().trim()
        val email: String = binding.editEmail.text.toString().trim()
        val password: String = binding.editPassword.text.toString().trim()

        if (fname.isBlank()) {
            Utils.toast(applicationContext, getString(R.string.err_text_fname))

            return false

        } else if (!Utils.isEmailVaild(email)) {
            Utils.toast(applicationContext, getString(R.string.err_text_email))

            return false

        } else if (!Utils.isPasswordVaild(password)) {
            Utils.toast(applicationContext, getString(R.string.err_text_password))

            return false

        }
        return true

    }

    private fun doRequestForRegister(userModel: UserModel) {
        showDialog()

        auth.createUserWithEmailAndPassword(userModel.email, userModel.password)
            .addOnCompleteListener(this) { task ->

                dismissDialog()
                if (task.isSuccessful) {

                    Utils.toast(applicationContext, getString(R.string.text_success_msg))
                    val user = auth.currentUser
                    if (user != null) {
                        userModel.id= user.uid
                    }
                    SharedPrefsHelper.setBooleanToPref(Constants.ISLOGIN, true)
                    SharedPrefsHelper.setUserDetails(userModel)

                    Utils.redirectToHome(getActivity())

                } else {

                    if (task.exception is FirebaseAuthUserCollisionException)

                        Utils.toast(applicationContext, getString(R.string.err_text_email_exist))
                    else Utils.toast(applicationContext, getString(R.string.err_text_failure))


                }
            }
    }

    private fun getActivity(): Activity {
        return this
    }
}