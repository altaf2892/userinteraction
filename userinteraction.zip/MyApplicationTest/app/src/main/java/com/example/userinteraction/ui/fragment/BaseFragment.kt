package com.example.userinteraction.ui.fragment

import android.os.Bundle
import androidx.annotation.LayoutRes
import androidx.fragment.app.Fragment
import com.example.userinteraction.utility.ProgressUtils
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import com.kaopiz.kprogresshud.KProgressHUD

open class BaseFragment(@LayoutRes contentLayoutId: Int) : Fragment(contentLayoutId) {
    val database = Firebase.database
    lateinit var auth: FirebaseAuth
    private var progressDialog: KProgressHUD? = null;

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        progressDialog = ProgressUtils.initProgressBar(activity);
        auth = Firebase.auth
    }
    fun gettaskRef(): DatabaseReference {

        return database.getReference("friends")
    }
    protected fun showLoader() {
        progressDialog?.show()
    }

    protected fun hideLoader() {
        progressDialog?.dismiss()
    }

}