package com.example.userinteraction.utility

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.util.Patterns
import android.widget.Toast
import com.example.userinteraction.ui.activity.LoginActivity
import com.example.userinteraction.ui.activity.MainActivity
import com.growhub.utility.SharedPrefsHelper
import java.text.SimpleDateFormat
import java.util.*

object Utils {


    fun isEmailVaild(email: String): Boolean {
        return !email.isBlank() && Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }

    fun isPasswordVaild(pwd: String): Boolean {
        return !pwd.isBlank() && pwd.length >= 6
    }

    fun toast(context: Context, msg: String) {
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
    }


    fun redirectToHome(context: Activity) {
        val i = Intent(context, MainActivity::class.java)
// set the new task and clear flags
        i.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        context.startActivity(i)
    }

    fun convertLongToTime(time: Long): String {
        val date = Date(time)
        val format = SimpleDateFormat("dd/MM/yyyy")
        return format.format(date)
    }

    fun isPhoneVaild(no: String): Boolean {
        if (no.length > 10 || no.length < 10)
            return false

        return true
    }

    fun isWebsiteVaild(website: String): Boolean {
        return Patterns.WEB_URL.matcher(website).matches()
    }

    fun logout(context: Activity) {
        SharedPrefsHelper.clear()
        val i = Intent(context, LoginActivity::class.java)
// set the new task and clear flags
        i.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        context.startActivity(i)
    }
}