package com.example.userinteraction.ui.activity

import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import com.example.userinteraction.R
import com.example.userinteraction.databinding.ActivityAddFriendBinding
import com.example.userinteraction.model.DataModel
import com.example.userinteraction.model.UserModel
import com.example.userinteraction.utility.Utils
import com.google.android.material.datepicker.CalendarConstraints
import com.google.android.material.datepicker.MaterialDatePicker
import com.growhub.utility.SharedPrefsHelper
import java.util.*


class AddFriendActivity : BaseActivity(), View.OnClickListener {
    private var selectedDate: Long = 0
    private lateinit var binding: ActivityAddFriendBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddFriendBinding.inflate(layoutInflater)
        setContentView(binding.root)
        init()


    }


    private fun init() {

        binding.apply {
            binding.editBirthday.setOnClickListener(this@AddFriendActivity)
            binding.btbAdd.setOnClickListener(this@AddFriendActivity)
        }


        setGenderAdapter()


    }


    private fun launchDatePicker() {
        val calendar = Calendar.getInstance()
        val upTo = calendar.timeInMillis
        calendar.set(1980, 1, 1)

        val constraints = CalendarConstraints.Builder()
            .setEnd(Calendar.getInstance().timeInMillis)
            .build()
        val picker =
            MaterialDatePicker.Builder.datePicker()
                .setCalendarConstraints(constraints)
                .setSelection(MaterialDatePicker.todayInUtcMilliseconds())
                .setInputMode(MaterialDatePicker.INPUT_MODE_CALENDAR)
                .setTitleText(getString(R.string.text_b_date))
                .build()
        picker.show(supportFragmentManager, "tag");

        picker.addOnPositiveButtonClickListener {
            // Respond to positive button click.


            binding.editBirthday.setText(Utils.convertLongToTime(it))

            selectedDate = it
        }
        picker.addOnNegativeButtonClickListener {
            // Respond to negative button click.
        }
        picker.addOnCancelListener {
            // Respond to cancel button click.
        }
        picker.addOnDismissListener {
            // Respond to dismiss events.
        }


    }

    private fun isValid(): Boolean {

        val fname: String = binding.editFname.text.toString().trim()

        val email: String = binding.editEmail.text.toString().trim()
        val phone: String = binding.editPhone.text.toString().trim()
        val bday: String = binding.editBirthday.text.toString().trim()
        val gender: String = binding.tvGender.text.toString()
        val street: String = binding.editStreet.text.toString().trim()
        val streetName: String = binding.editStreetName.text.toString().trim()
        val buildingNumber: String = binding.editBuildingNumber.text.toString().trim()
        val city: String = binding.editCity.text.toString().trim()
        val zipcode: String = binding.editZipcode.text.toString().trim()
        val country: String = binding.editCountry.text.toString().trim()
        val country_code: String = binding.editCountyCode.text.toString().trim()
        val lat: String = binding.editLatitude.text.toString().trim()
        val lon: String = binding.editLongitude.text.toString().trim()
        val website: String = binding.editWebsite.text.toString().trim()

        if (fname.isEmpty()) {
            Utils.toast(getActivity(), getString(R.string.err_text_fname))
            return false
        }  else if (email.isEmpty() || !Utils.isEmailVaild(email)) {
            Utils.toast(getActivity(), getString(R.string.err_text_email))
            return false
        } else if (phone.isEmpty() || !Utils.isPhoneVaild(phone)) {
            Utils.toast(getActivity(), getString(R.string.err_text_phone))
            return false
        } else if (bday.isEmpty()) {
            Utils.toast(getActivity(), getString(R.string.err_text_bday))
            return false
        } else if (gender.isEmpty()) {
            Utils.toast(getActivity(), getString(R.string.err_text_gender))
            return false
        } else if (street.isEmpty()) {
            Utils.toast(getActivity(), getString(R.string.err_text_street))
            return false
        } else if (streetName.isEmpty()) {
            Utils.toast(getActivity(), getString(R.string.err_text_streetName))
            return false
        } else if (buildingNumber.isEmpty()) {
            Utils.toast(getActivity(), getString(R.string.err_text_buildingNumber))
            return false
        } else if (city.isEmpty()) {
            Utils.toast(getActivity(), getString(R.string.err_text_city))
            return false
        } else if (zipcode.isEmpty()) {
            Utils.toast(getActivity(), getString(R.string.err_text_zipcode))
            return false
        } else if (country.isEmpty()) {
            Utils.toast(getActivity(), getString(R.string.err_text_country))
            return false
        } else if (country_code.isEmpty()) {
            Utils.toast(getActivity(), getString(R.string.err_text_country_code))
            return false
        } else if (lat.isEmpty()) {
            Utils.toast(getActivity(), getString(R.string.err_text_lat))
            return false
        } else if (lon.isEmpty()) {
            Utils.toast(getActivity(), getString(R.string.err_text_lon))
            return false
        } else if (website.isEmpty() || Utils.isWebsiteVaild(website)) {
            Utils.toast(getActivity(), getString(R.string.err_text_website))
            return false
        }

        return true
    }

    private fun setGenderAdapter() {
        val items = listOf("Male", "Female")
        val adapter = ArrayAdapter(getActivity(), R.layout.list_item, items)
        (binding.tvGender as? AutoCompleteTextView)?.setAdapter(adapter)
    }

    private fun getActivity(): AddFriendActivity {
        return this@AddFriendActivity
    }

    override fun onClick(v: View?) {

        when (v?.id) {
            R.id.edit_birthday -> {
                launchDatePicker()
            }

            R.id.btb_add -> {
                if (isValid()) {
                    val fname: String = binding.editFname.text.toString().trim()

                    val email: String = binding.editEmail.text.toString().trim()
                    val phone: String = binding.editPhone.text.toString().trim()
                    //  val bday: String = binding.editBirthday.text.toString().trim()

                    val gender: String = binding.tvGender.text.toString()
                    val street: String = binding.editStreet.text.toString().trim()
                    val streetName: String = binding.editStreetName.text.toString().trim()
                    val buildingNumber: String = binding.editBuildingNumber.text.toString().trim()
                    val city: String = binding.editCity.text.toString().trim()
                    val zipcode: String = binding.editZipcode.text.toString().trim()
                    val country: String = binding.editCountry.text.toString().trim()
                    val country_code: String = binding.editCountyCode.text.toString().trim()
                    val lat: String = binding.editLatitude.text.toString().trim()
                    val lon: String = binding.editLongitude.text.toString().trim()
                    val website: String = binding.editWebsite.text.toString().trim()
                    val userEmail: UserModel? = SharedPrefsHelper.getUserDetails()
                    showDialog()

                    val model = DataModel()
                    model.fullname = fname
                    model.email = email
                    model.phone = phone
                    model.gender = gender
                    val address = DataModel.AddressModel()
                    address.street = street
                    address.streetName = streetName
                    address.buildingNumber = buildingNumber
                    address.city = city
                    address.country = country
                    address.county_code = country_code
                    address.latitude = lon
                    address.longitude = lat
                    address.zipcode = zipcode
                    val id = UUID.randomUUID().toString();

                    model._id = id
                    model.addressModel = address
                    model.birthday = selectedDate
                    model.usrr_email = userEmail!!.email
                    model.website = website


                    gettaskRef().child(userEmail?.id.toString())
                        .child(id)
                        .setValue(model)
                        .addOnSuccessListener {
                            dismissDialog()
                            Utils.toast(applicationContext, getString(R.string.text_added))
                            finish()

                        }.addOnFailureListener {
                            dismissDialog()
                            Utils.toast(applicationContext, getString(R.string.text_added_fail))
                        }
                }
            }
        }

    }

}