package com.example.userinteraction.ui.activity

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import com.example.userinteraction.R
import com.example.userinteraction.databinding.ActivityLoginBinding
import com.example.userinteraction.model.UserModel
import com.example.userinteraction.utility.Constants
import com.example.userinteraction.utility.Utils
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.growhub.utility.SharedPrefsHelper

class LoginActivity : BaseActivity() {

    lateinit var binding: ActivityLoginBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
        init()
    }

    private fun init() {


        binding.btbLogin.setOnClickListener {
            if (isValid()) {
                val email: String = binding.editEmail.text.toString().trim()
                val password: String = binding.editPassword.text.toString().trim()
                doRequestForLogin(email, password)

            }


        }

        binding.tvRegister.setOnClickListener {
            startActivity(Intent(applicationContext, RegisterActivity::class.java))
        }

    }

    private fun isValid(): Boolean {
        val email: String = binding.editEmail.text.toString().trim()
        val password: String = binding.editPassword.text.toString().trim()

        if (!Utils.isEmailVaild(email)) {
            Utils.toast(applicationContext, getString(R.string.err_text_email))

            return false

        } else if (!Utils.isPasswordVaild(password)) {
            Utils.toast(applicationContext, getString(R.string.err_text_password))

            return false

        }
        return true

    }

    private fun doRequestForLogin(email: String, password: String) {
        showDialog()

        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {

                    Utils.toast(applicationContext, getString(R.string.text_success_msg))
                    dismissDialog()
                    val user = auth.currentUser

                    SharedPrefsHelper.setBooleanToPref(Constants.ISLOGIN, true)
                    SharedPrefsHelper.setUserDetails(
                        UserModel(
                            user!!.displayName.toString(),
                            email,
                            password, user.uid
                        )
                    )


                    Utils.redirectToHome(getActivity())

                } else {

                    Log.e("TEST", task.exception.toString())
                    dismissDialog()
                    if (task.exception is FirebaseAuthInvalidUserException)

                        Utils.toast(
                            applicationContext,
                            getString(R.string.err_text_email_password_)
                        )
                    else Utils.toast(applicationContext, getString(R.string.err_text_failure))


                }
            }
    }

    private fun getActivity(): Activity {
        return this
    }
}