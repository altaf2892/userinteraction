package com.example.userinteraction.model

data class UserModel(val full_name: String, val email: String, val password: String,var id:String)
